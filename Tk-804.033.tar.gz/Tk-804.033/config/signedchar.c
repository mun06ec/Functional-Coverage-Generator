main()
{
 signed char x = 'a';
 return (x - 'a');
}
