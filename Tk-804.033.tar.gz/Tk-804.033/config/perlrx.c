#include <EXTERN.h>
#include <perl.h>
#include <XSUB.h>

int main() {
    regexp re;
    void *p;
    p = re.offs;
    return 0;
}
