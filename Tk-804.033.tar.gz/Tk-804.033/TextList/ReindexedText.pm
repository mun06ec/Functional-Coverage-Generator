use strict;
package Tk::ReindexedText;

use vars qw($VERSION);
$VERSION = '4.004'; # $Id: //depot/Tkutf8/TextList/ReindexedText.pm#4 $

use Tk::Reindex qw(Tk::Text);
use base qw(Tk::Reindex Tk::Text);
Construct Tk::Widget 'ReindexedText';

1;


