# Copyright (c) 1995-2003 Nick Ing-Simmons. All rights reserved.
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl itself.
package Tk::Menubar;
use strict;

use vars qw($VERSION);
$VERSION = '4.006'; # $Id: //depot/Tkutf8/Tk/Menubar.pm#6 $

use Tk::Frame;
use Tk::Menu;
# use Carp;
# carp "Tk::Menubar is obsolete" if $^W;

1;
