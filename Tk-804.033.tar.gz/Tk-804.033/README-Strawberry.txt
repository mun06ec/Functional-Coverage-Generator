Tk804.031_501 should work with 32bit and 64bit standard and portable
Strawberry Perl 5.18.1.1

The *portable* Strawberry Perl 5.12.3.0 has some problems with the
bundled Config.pm which prevents a successful compilation of Tk. A fix
is proposed in http://rt.cpan.org/Public/Bug/Display.html?id=68937

